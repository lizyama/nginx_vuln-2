# Скрипты для воспроизведения уязвимости ngx_http_exstatus_module

Состав архива `nginx_extstatus_repro_scripts.zip` (папка `scripts/`):

| Файл | Назначение |
| --- | --- |
| `check_env.sh` | Разведка стенда: версия/сборка, `--add-module`, эндпоинты, логи, процессы, память. Ничего не меняет. |
| `watch_nginx.sh` | Живое наблюдение за мастером/воркерами и error.log. В отдельном терминале. |
| `reload_probe.sh` | Сценарий 1: reload + первый запрос к эндпоинту, поиск падений воркеров. |
| `apply_prlimit.sh` | Сценарий 2, метод A: RLIMIT_AS уже работающим процессам (show / apply / restore). |
| `status_stress.py` | Сценарий 2: держащие соединения + опрос эндпоинта, фиксация аномалий. |
| `memhog.py` | Сценарий 2, метод C (грубый): давление на память всей машины. |
| `collect_evidence.sh` | Сбор улик после падения: логи, dmesg, addr2line, core dump, тела ответов. |

## Важно для форков nginx (например, syngx)

Если бинарник называется не `nginx`, а иначе (например, `syngx`), **ничего переписывать
не нужно**: все bash-скрипты сами находят бинарник — сначала `syngx`, затем `nginx`.
Если путь нестандартный, задайте переменную:

```bash
NGINX_BIN=/opt/syngx/sbin/syngx sudo -E bash check_env.sh
```

`check_env.sh` покажет параметры сборки (`--add-module`) именно вашего бинарника
и отдельной строкой проверит наличие модуля `exstatus`. Имя systemd-юнита
(`syngx.service` / `nginx.service`) тоже определяется автоматически;
его можно задать вручную: `NGINX_UNIT=syngx.service`.

## Если скрипт падает с ошибками вида `$'\r': command not found`

Это «оконные» переводы строк (CRLF), появившиеся при передаче файлов через Windows.
Bash их не понимает. Лечится одной командой (dos2unix устанавливать не нужно):

```bash
sed -i 's/\r$//' *.sh *.py
```

После этого запускайте скрипты как обычно: `sudo bash check_env.sh`.

## Требования

- bash, python3 (только стандартная библиотека), curl — ничего устанавливать не нужно;
- root (sudo) — нужны для reload, prlimit, dmesg, чтения логов;
- запуск — только на выделенном тестовом стенде.

## Порядок работы (соответствует этапам инструкции)

1. `sudo bash check_env.sh` — разведка, записать URL эндпоинта и путь к error.log.
2. В отдельном окне: `sudo bash watch_nginx.sh`.
3. Сценарий 1: `sudo bash reload_probe.sh http://127.0.0.1:ПОРТ/ПУТЬ 8`.
4. Если падений нет — Сценарий 2, метод A:
   `sudo bash apply_prlimit.sh apply 4096`, затем
   `sudo python3 status_stress.py --url http://127.0.0.1:ПОРТ/ПУТЬ --conns 800 --hold 90 --poll 0.2`.
5. После падения: `sudo bash collect_evidence.sh http://127.0.0.1:ПОРТ/ПУТЬ`.
6. Восстановление: `sudo bash apply_prlimit.sh restore` (+ мягкая перезагрузка воркеров).
